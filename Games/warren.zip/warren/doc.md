To do
Place Trees
Add Health
Add Dash
Add Stamina
Add new map climates, Grassy, Arid, Rocky, Desert
Help How to Play With Badger?
Warren Screen where you customise, go on missions and bring back bunnies and food
Add Entrance Tunnel/ Quit back to Warren in Pause (in case level generated is impossible, or to scum out)
Friendly Rabbbits, follow you when near, until a opened tunnel is near which they go in and are safe

Badger You can Talk to:
Hello/ What are we doing again?
Badger: Once our Warren was vast and plentiful, with all kinds of creatures and food, and a tunnel system all over these fair lands
Badger: But soon all these new predators came, and our people are scattered and afraid.
Badger: If only some brave heroes could rebuild it, uncover our tunnel network and unite us all once again
How do I play?
Badger: [PC] Press the WASD/Arrow Keys to Move, and press space bar to interact
Badger: Hold Interact on covered tunnels to dig them out so we can use them again
Uncover the main tunnels in each place you go, and you

Warren: Decorate, see your bunnies and stores, choose a bunny to be play as and rename/customise/view stats
Head Into Tunnels? Yes/No takes you to a mission

Assets:
Twigs
Wooden Furniture: a Stool, A chair, A single tile table, a long table, a bed,
Types of Rabbit: Different colours. Maybe some have clothes


3 star ranking and Score and Time Taken?
1 Star = Completed Mandatory
2 Star = Completed Mandatory + Optional
3 Star = Completionist
How does Performance Ranking Tie in? Reputation of Warren? Stats increase on Bunny?

Mandatory: Find the Exit Tunnel
Optional: Don't Use Dash
Optional: Don't Use Dash more than 3 times
Optional: Complete in under 60 seconds
Optional: Don't Take Damage
Optional: Rescue All Bunnies
Optional: Collect All Carrots
Optional: Collect All Berries
Optional: Uncover All Holes

Achievements: 

Participation Trophy: Rank 1 - Complete 3 levels, Rank 2, Complete 10 Levels
Speedy Thief: Rank 1 - Complete
Fixer Upper Rank 1: - Uncover 3 Tunnels, Rank 2 - Uncover 10 Tunnels, Rank 3 - Uncover 25 Tunnels, Rank 4 - Uncover 50 Tunnels, Rank 5 - Uncover 100 Tunnels

Rescuer: Rank 1 - Rescue 3 Bunnies, Rank 2 - Rescue 10 Bunnies, Rank 3 - Rescue 25 Bunnies, Rank 4- Rescue 50 Bunnies, Rank 5 - Rescue 100 Bunnies
(not the same, as warren number changes or has max)
Community Builder: Rank 1 - Have 3 Bunnies at Warren, Rank 2 - Have 10 Bunnies at Warren, Rank 3 - Have 25 Bunnies at Warren,  Rank 4 - Have 50 Bunnies at Warren, Rank 5 = Have 100 Bunnies At Warren

Rabbit Fashion: Rank 1 - Discover 3 Bunny Looks, Rank 2 - Discover 5 Bunny Looks, Rank 3 - Discover 8 Bunny Looks
Home Maker: Rank 1 - Place 3 furniture
Carrot Collector: Rank 1 - Bring Back 3 Carrots At Warren
Berry Grabber: Rank 1 - Collect 3 berries
Twig Snatcher: Rank 1 - Collect 3 twigs
Collector: Rank 1: Reach Rank 1 in Carrot Collector, Berry Grabber, Twig Snatcher

Ghost: Rank 1 - Die 3 times

Save and Load Your Customised Warren with what you've collected.
Bunnies you Rescue eat supply? Need More Rooms in Warren? Otherwise cant keep rescued bunnies or they starve
Maybe if you die as bunny you lose that bunny? Each bunny has a name?
start of in a warren of 3 bunnies. the more you use a bunny the better its stamina and health gets?
when you bring back to warren every mission you do progresses some time on bunnies still at warren so if hurt they recover health a bit

Pick up Twigs and sticks to make furniture with?


Old---
Mission Script -
Mandatory/Optional Objectives = Collect All Carrots

title menu -
pause menu - 
You Win/Game Over -
Hold on a covered tunnel to dig it open for a few seconds.

Tunnells teleport you to a random other tunnel

Eat all the Carrots
Carrots are health, like rings, you can take damage but lose carrot?

friendly bunnies

save scared bunnies who follow you back to their homes/burrows/warrens

generate levels

handmade levels?

Short Dash? Little Stamina Meter you can upgrade?
pick up traps and drop them in Fox's way to trap them for some time.
Go through tunnels foxes can't
Jump across short obstacles or water tiles

scary music when fox attacks.
multiple foxes?

Little Burrow you upgrade and decorate with your bunny family?
customise your Bunny?

collect flowers and seeds from world and bring back to plant at home?

7 harry potter length books
merchandise
$$$ £££